package com.ntt.hai;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        product p=new product();
        p.printdata();
    }
}
